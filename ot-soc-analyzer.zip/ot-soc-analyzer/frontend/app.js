// API Configuration
const API_URL = 'http://localhost:5000';

// DOM Elements
const uploadSection = document.getElementById('upload-section');
const uploadBtn = document.getElementById('upload-btn');
const fileInput = document.getElementById('file-input');
const loading = document.getElementById('loading');
const dashboard = document.getElementById('dashboard');
const generateReportBtn = document.getElementById('generate-report-btn');
const resetBtn = document.getElementById('reset-btn');

// New Feature Elements
const alertRulesBtn = document.getElementById('alert-rules-btn');
const threatIntelBtn = document.getElementById('threat-intel-btn');
const exportSiemBtn = document.getElementById('export-siem-btn');

// Modals
const alertRulesModal = document.getElementById('alert-rules-modal');
const threatIntelModal = document.getElementById('threat-intel-modal');
const exportSiemModal = document.getElementById('export-siem-modal');

// State
let currentResults = null;
let customRules = [];
let detectedIPs = [];

// Event Listeners
uploadBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', handleFileUpload);
generateReportBtn.addEventListener('click', generateReport);
resetBtn.addEventListener('click', resetAnalysis);

// New Feature Listeners
alertRulesBtn.addEventListener('click', () => openModal(alertRulesModal));
threatIntelBtn.addEventListener('click', () => openModal(threatIntelModal));
exportSiemBtn.addEventListener('click', () => openModal(exportSiemModal));

// Modal Close Listeners
document.getElementById('close-alert-modal').addEventListener('click', () => closeModal(alertRulesModal));
document.getElementById('close-intel-modal').addEventListener('click', () => closeModal(threatIntelModal));
document.getElementById('close-siem-modal').addEventListener('click', () => closeModal(exportSiemModal));

// Close modal on background click
[alertRulesModal, threatIntelModal, exportSiemModal].forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal(modal);
    });
});

// Alert Rules Functions
document.getElementById('add-rule-btn').addEventListener('click', addCustomRule);

// Threat Intel Functions
document.getElementById('lookup-ip-btn').addEventListener('click', lookupThreatIntel);

// SIEM Export Functions
document.getElementById('export-cef').querySelector('button').addEventListener('click', () => exportSIEM('cef'));
document.getElementById('export-json').querySelector('button').addEventListener('click', () => exportSIEM('json'));
document.getElementById('export-syslog').querySelector('button').addEventListener('click', () => exportSIEM('syslog'));
document.getElementById('export-csv').querySelector('button').addEventListener('click', () => exportSIEM('csv'));

// File Upload Handler
async function handleFileUpload(event) {
    const file = event.target.files[0];
    
    if (!file) return;
    
    if (!file.name.endsWith('.csv')) {
        alert('Please upload a CSV file');
        return;
    }
    
    // Show loading
    uploadSection.classList.add('hidden');
    loading.classList.remove('hidden');
    
    // Create form data
    const formData = new FormData();
    formData.append('file', file);
    
    try {
        const response = await fetch(`${API_URL}/upload`, {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentResults = data.results;
            displayResults(currentResults);
            loading.classList.add('hidden');
            dashboard.classList.remove('hidden');
        } else {
            throw new Error(data.error || 'Upload failed');
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
        loading.classList.add('hidden');
        uploadSection.classList.remove('hidden');
    }
}

// Display Results
function displayResults(results) {
    // Risk Score
    document.getElementById('risk-score').textContent = results.risk_score;
    const severityBadge = document.getElementById('severity-badge');
    severityBadge.textContent = results.severity;
    severityBadge.className = `severity-badge ${results.severity}`;
    
    // Attack Detection Stats
    document.getElementById('total-packets').textContent = results.total_packets.toLocaleString();
    document.getElementById('attack-count').textContent = results.attack_count.toLocaleString();
    document.getElementById('normal-count').textContent = results.normal_count.toLocaleString();
    document.getElementById('attack-percentage').textContent = results.attack_percentage;
    
    // Critical Alerts
    displayCriticalAlerts(results.critical_alerts);
    
    // Protocol Distribution
    displayProtocols(results.protocols);
    
    // Timeline
    displayTimeline(results.timeline);
    
    // Devices
    displayDevices(results.devices);
    
    // Extract IPs for threat intel
    extractIPsFromResults();
}

// Display Critical Alerts
function displayCriticalAlerts(alerts) {
    const container = document.getElementById('critical-alerts-container');
    container.innerHTML = '';
    
    if (!alerts || alerts.length === 0) {
        container.innerHTML = '<p class="no-data">No critical alerts detected</p>';
        return;
    }
    
    alerts.slice(0, 3).forEach(alert => {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert-item ${alert.severity}`;
        alertDiv.innerHTML = `
            <div class="alert-id">${alert.id} - ${alert.severity}</div>
            <div class="alert-desc">${alert.description}</div>
        `;
        container.appendChild(alertDiv);
    });
}

// Display Protocol Distribution
function displayProtocols(protocols) {
    const container = document.getElementById('protocol-chart');
    container.innerHTML = '';
    
    if (!protocols || Object.keys(protocols).length === 0) {
        container.innerHTML = '<p class="no-data">No protocol data available</p>';
        return;
    }
    
    const total = Object.values(protocols).reduce((sum, count) => sum + count, 0);
    
    Object.entries(protocols).forEach(([protocol, count]) => {
        const percentage = ((count / total) * 100).toFixed(1);
        
        const barDiv = document.createElement('div');
        barDiv.className = 'protocol-bar';
        barDiv.innerHTML = `
            <div class="protocol-label">
                <span>${protocol}</span>
                <span>${count.toLocaleString()} packets</span>
            </div>
            <div class="protocol-progress">
                <div class="protocol-fill" style="width: ${percentage}%">${percentage}%</div>
            </div>
        `;
        container.appendChild(barDiv);
    });
}

// Display Timeline
function displayTimeline(timeline) {
    const container = document.getElementById('timeline-chart');
    container.innerHTML = '';
    
    if (!timeline || timeline.length === 0) {
        container.innerHTML = '<p class="no-data">No timeline data available</p>';
        return;
    }
    
    timeline.forEach(item => {
        const timeDiv = document.createElement('div');
        timeDiv.className = 'timeline-item';
        timeDiv.innerHTML = `
            <span class="timeline-time">${item.time}</span>
            <span class="timeline-count">${item.count} attacks</span>
        `;
        container.appendChild(timeDiv);
    });
}

// Display Devices
function displayDevices(devices) {
    const container = document.getElementById('devices-list');
    container.innerHTML = '';
    
    if (!devices || devices.length === 0) {
        container.innerHTML = '<p class="no-data">No device data available</p>';
        return;
    }
    
    devices.forEach(device => {
        const deviceDiv = document.createElement('div');
        deviceDiv.className = 'device-item';
        deviceDiv.innerHTML = `
            <div class="device-name">${device.device}</div>
            <div class="device-stats">
                <span>Type: ${device.type}</span>
                <span>${device.packets.toLocaleString()} packets</span>
            </div>
        `;
        container.appendChild(deviceDiv);
    });
}

// Generate PDF Report
async function generateReport() {
    if (!currentResults) {
        alert('No analysis data available');
        return;
    }
    
    try {
        generateReportBtn.disabled = true;
        generateReportBtn.textContent = '⏳ Generating...';
        
        const response = await fetch(`${API_URL}/report`, {
            method: 'POST'
        });
        
        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `OT_SOC_Report_${new Date().getTime()}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } else {
            throw new Error('Report generation failed');
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
    } finally {
        generateReportBtn.disabled = false;
        generateReportBtn.textContent = '📄 Generate PDF Report';
    }
}

// Reset Analysis
async function resetAnalysis() {
    if (!confirm('Are you sure you want to reset the analysis?')) {
        return;
    }
    
    try {
        await fetch(`${API_URL}/reset`, {
            method: 'POST'
        });
        
        currentResults = null;
        customRules = [];
        detectedIPs = [];
        fileInput.value = '';
        dashboard.classList.add('hidden');
        uploadSection.classList.remove('hidden');
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

// ===== MODAL MANAGEMENT =====
function openModal(modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeModal(modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
}

// ===== CUSTOM ALERT RULES =====
function addCustomRule() {
    const name = document.getElementById('rule-name').value.trim();
    const protocol = document.getElementById('rule-protocol').value;
    const condition = document.getElementById('rule-condition').value;
    const threshold = document.getElementById('rule-threshold').value;
    const severity = document.getElementById('rule-severity').value;
    
    if (!name) {
        alert('Please enter a rule name');
        return;
    }
    
    const rule = {
        id: Date.now(),
        name,
        protocol,
        condition,
        threshold,
        severity,
        enabled: true
    };
    
    customRules.push(rule);
    displayCustomRules();
    
    // Clear form
    document.getElementById('rule-name').value = '';
    document.getElementById('rule-threshold').value = '100';
}

function displayCustomRules() {
    const container = document.getElementById('active-rules-container');
    
    if (customRules.length === 0) {
        container.innerHTML = '<p class="no-data">No custom rules defined</p>';
        return;
    }
    
    container.innerHTML = '';
    customRules.forEach(rule => {
        const ruleDiv = document.createElement('div');
        ruleDiv.className = 'rule-item';
        ruleDiv.innerHTML = `
            <div class="rule-info">
                <div class="rule-name">${rule.name}</div>
                <div class="rule-details">
                    Protocol: ${rule.protocol} | Condition: ${rule.condition} | 
                    Threshold: ${rule.threshold} | Severity: ${rule.severity}
                </div>
            </div>
            <div class="rule-actions">
                <button onclick="deleteRule(${rule.id})">Delete</button>
            </div>
        `;
        container.appendChild(ruleDiv);
    });
}

function deleteRule(ruleId) {
    customRules = customRules.filter(r => r.id !== ruleId);
    displayCustomRules();
}

// ===== THREAT INTELLIGENCE =====
async function lookupThreatIntel() {
    const ipInput = document.getElementById('ip-search').value.trim();
    
    if (!ipInput) {
        alert('Please enter an IP address');
        return;
    }
    
    // Validate IP format
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRegex.test(ipInput)) {
        alert('Invalid IP address format');
        return;
    }
    
    const loadingDiv = document.getElementById('intel-loading');
    const resultsDiv = document.getElementById('intel-results');
    
    loadingDiv.classList.remove('hidden');
    resultsDiv.classList.add('hidden');
    
    // Simulate threat intel lookup (in production, this would call AbuseIPDB or VirusTotal API)
    setTimeout(() => {
        loadingDiv.classList.add('hidden');
        resultsDiv.classList.remove('hidden');
        
        // Simulated response
        const isMalicious = Math.random() > 0.7; // 30% chance of being flagged
        const abuseScore = isMalicious ? Math.floor(Math.random() * 50) + 50 : Math.floor(Math.random() * 20);
        
        resultsDiv.innerHTML = `
            <div class="intel-status ${isMalicious ? 'malicious' : 'safe'}">
                <span>${isMalicious ? '⚠️' : '✅'}</span>
                <span>${isMalicious ? 'THREAT DETECTED' : 'NO THREATS FOUND'}</span>
            </div>
            <div class="intel-details">
                <div class="intel-field">
                    <span class="intel-label">IP Address:</span>
                    <span class="intel-value">${ipInput}</span>
                </div>
                <div class="intel-field">
                    <span class="intel-label">Abuse Confidence Score:</span>
                    <span class="intel-value">${abuseScore}%</span>
                </div>
                <div class="intel-field">
                    <span class="intel-label">Reports:</span>
                    <span class="intel-value">${isMalicious ? Math.floor(Math.random() * 100) + 10 : 0}</span>
                </div>
                <div class="intel-field">
                    <span class="intel-label">Last Seen:</span>
                    <span class="intel-value">${isMalicious ? 'Within 24 hours' : 'No recent activity'}</span>
                </div>
                <div class="intel-field">
                    <span class="intel-label">Categories:</span>
                    <span class="intel-value">${isMalicious ? 'Port Scan, Brute Force' : 'None'}</span>
                </div>
            </div>
            <p style="margin-top: 15px; font-size: 12px; color: #6b7280; font-style: italic;">
                Note: This is a simulated lookup. In production, this would query real threat intelligence databases like AbuseIPDB or VirusTotal.
            </p>
        `;
    }, 1500);
}

function extractIPsFromResults() {
    if (!currentResults || !currentResults.devices) {
        return;
    }
    
    detectedIPs = currentResults.devices.map(device => device.device).filter(ip => {
        // Basic IP validation
        return /^(\d{1,3}\.){3}\d{1,3}$/.test(ip);
    });
    
    displayDetectedIPs();
}

function displayDetectedIPs() {
    const container = document.getElementById('detected-ips-list');
    
    if (detectedIPs.length === 0) {
        container.innerHTML = '<p class="no-data">No IP addresses detected in analysis</p>';
        return;
    }
    
    container.innerHTML = '';
    detectedIPs.forEach(ip => {
        const badge = document.createElement('span');
        badge.className = 'ip-badge';
        badge.textContent = ip;
        badge.onclick = () => {
            document.getElementById('ip-search').value = ip;
            lookupThreatIntel();
        };
        container.appendChild(badge);
    });
}

// ===== SIEM EXPORT =====
function exportSIEM(format) {
    if (!currentResults) {
        alert('No analysis data available to export');
        return;
    }
    
    let exportData = '';
    let filename = '';
    let mimeType = '';
    
    switch(format) {
        case 'cef':
            exportData = generateCEF();
            filename = 'ot_soc_alerts.cef';
            mimeType = 'text/plain';
            break;
        case 'json':
            exportData = generateJSON();
            filename = 'ot_soc_alerts.json';
            mimeType = 'application/json';
            break;
        case 'syslog':
            exportData = generateSyslog();
            filename = 'ot_soc_alerts.log';
            mimeType = 'text/plain';
            break;
        case 'csv':
            exportData = generateCSV();
            filename = 'ot_soc_alerts.csv';
            mimeType = 'text/csv';
            break;
    }
    
    // Show preview
    document.getElementById('export-preview-content').innerHTML = `<code>${escapeHtml(exportData)}</code>`;
    
    // Download file
    const blob = new Blob([exportData], { type: mimeType });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
}

function generateCEF() {
    // Common Event Format (CEF)
    const alerts = currentResults.critical_alerts || [];
    let cef = '';
    
    alerts.forEach(alert => {
        const timestamp = new Date().toISOString();
        cef += `CEF:0|SyreOps|OT-SOC-Analyzer|1.0|${alert.id}|${alert.description}|${getSeverityNumber(alert.severity)}|rt=${timestamp} src=Unknown dst=ICS_Network act=Alert msg=${alert.description}\n`;
    });
    
    return cef || 'No alerts to export';
}

function generateJSON() {
    const exportObj = {
        timestamp: new Date().toISOString(),
        source: 'SyreOps OT-SOC Analyzer',
        risk_score: currentResults.risk_score,
        severity: currentResults.severity,
        total_packets: currentResults.total_packets,
        attack_count: currentResults.attack_count,
        alerts: currentResults.critical_alerts,
        mitre_mappings: currentResults.mitre_mappings,
        soc_context: currentResults.soc_context
    };
    
    return JSON.stringify(exportObj, null, 2);
}

function generateSyslog() {
    // RFC 5424 Syslog format
    const alerts = currentResults.critical_alerts || [];
    let syslog = '';
    
    alerts.forEach(alert => {
        const timestamp = new Date().toISOString();
        const priority = getSeverityNumber(alert.severity);
        syslog += `<${priority}>1 ${timestamp} ot-soc-analyzer - - - ${alert.id} ${alert.description}\n`;
    });
    
    return syslog || 'No alerts to export';
}

function generateCSV() {
    const alerts = currentResults.critical_alerts || [];
    let csv = 'Timestamp,Alert_ID,Severity,Risk_Score,Description\n';
    
    const timestamp = new Date().toISOString();
    alerts.forEach(alert => {
        csv += `${timestamp},${alert.id},${alert.severity},${alert.risk_score},"${alert.description}"\n`;
    });
    
    return csv;
}

function getSeverityNumber(severity) {
    const map = {
        'CRITICAL': 1,
        'HIGH': 3,
        'MEDIUM': 5,
        'LOW': 7,
        'INFORMATIONAL': 9
    };
    return map[severity] || 5;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}